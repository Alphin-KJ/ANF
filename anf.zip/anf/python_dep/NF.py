import pprint
import requests  
import sys



#!pip3 install newspaper3k
from newspaper import Article
from datetime import datetime



def NewsScrap(url):
  toi_article = Article(url, language="en")
  toi_article.download()
  toi_article.parse()   
  #print(toi_article.title)
  #open('NewsFile.txt', 'w').close()
  text_file = open("NewsFile.txt", "a")
  #text_file = open(toi_article.title, "w")
  text_file.write("\n"+toi_article.title+"\n")
  text_file.write(toi_article.text)
  text_file.close()

# Define the endpoint

def main():
    keyword="india"
    try:
      keyword=sys.argv[1]  
    except:
        print("\n\tGetting Indian News......\n")
    url = 'https://newsapi.org/v2/everything?'
    secret = 'e47930ee802249a08440afd84151e408'
    parameters = {
    
        'q': keyword, # query phrase
        'pageSize': 10,  # maximum is 100
        'apiKey': secret, # your own API key
        'from_param':datetime.today().strftime('%Y-%m-%d')

        }
    # Make the request

    response = requests.get(url, params=parameters)
    response_json = response.json()

    for i in response_json['articles']:
        print("\n___________________________________\n")
        print(i['url'])
        NewsScrap(i['url'])
        print("\n___________________________________\n")


if __name__ == '__main__':
    main()