package com.christ.anf;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

//import java.util.Arrays;

public class NewsFinder {
    public void main(String keyword) throws IOException, InterruptedException
    {
        File fileToDelete= new File("/Users/alphinkj/Desktop/ANF", "NewsFile.txt");
        if(fileToDelete.delete()){
        System.out.println("Deleted Old News Data");
    }    
    else {
        System.out.println("No old file to delete");
    }
        Process p = Runtime.getRuntime().exec("python3 /Users/alphinkj/Desktop/ANF/anf/python_dep/NF.py "+keyword);
        BufferedReader stdInput = new BufferedReader(new 
                 InputStreamReader(p.getInputStream()));

            BufferedReader stdError = new BufferedReader(new 
                 InputStreamReader(p.getErrorStream()));

        // read the output from the command
        System.out.println("\nNews Fetching in progress...\n");
        String s;
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }

        // read any errors from the attempted command
        System.out.println("Here is the standard error of the command (if any):\n");
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }

        DataCapture arrObj[]= new DataCapture[5];
        new OCR();
        DataCapture dp= new DataCapture(trends());
        String val[]=trends();
        for(int i=0;i<4;i++){
            arrObj[i]= new DataCapture(val[i]);
        }
        //String tn=dp.news("keyword");
        //System.out.println("\n"+tn);
    }
    protected String[] trends(){
        String array[] = {"Russia","Kohili","Election","Congress"};
        return array;
    } 
    public String[] google_trends(){
        String array[] = {"Michel Jacson","You","Rahul Gandhi","Congress","Russia"};
        return array;
    }
    public String[] find_repeats(){
        String array[] = {"Russia","Congress"};
        return array;
    }

}

