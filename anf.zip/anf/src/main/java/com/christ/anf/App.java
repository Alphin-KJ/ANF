package com.christ.anf;

import java.io.IOException;
import java.util.Random;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;



//import java.io.File;

// import net.sourceforge.tess4j.Tesseract;
// import net.sourceforge.tess4j.TesseractException;
//import com.christ.*;

public class App 
{
    static StringBuffer API=new StringBuffer();
    public static StringBuffer APIgenerator(){
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 43) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
          API.append(saltStr);
          API.reverse();
          API.replace(3, 7, "kiN8");
        return API;

    }
    
    static{
        System.out.println("\nConnecting to tenserflow servers...\n");
        //API.append("Ayz342kjbtb4t5jt5ktn23kj3kdjncskjncsk");
       // API.reverse();
       APIgenerator();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            System.out.println("\nConnection refused check your internet conncetion!\n");
            e.printStackTrace();
        }
    }
    public static void main( String[] args ) throws IOException, InterruptedException
    {
        String News_Keyword="00";
       
        try{
            News_Keyword=args[1];
            String username=args[0];
            System.out.println("\nYour API key " +username+" : \n" +API);
        } catch (Exception e){
            System.out.println("\nExpecting Username and News Keyword as Command Line argument: \n Switch to default public API....\n " +API);
            try {
                Thread.sleep(2000);
            } catch (InterruptedException k) {
                // TODO Auto-generated catch block
                k.printStackTrace();
            }
        }
        
        
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        clearScreen();
        NewsFinder nf= new NewsFinder();
        nf.main(News_Keyword);
        DataManager dm= new DataManager();
        try {
            DataManager.playAudio();
        } catch (UnsupportedAudioFileException | LineUnavailableException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(dm.retrivreData("10/02/22", "Vladimir Putin War\n"));
        clearScreen();
        System.out.println("\n----------------------------------------\n");
        System.out.println(dm.retrivreData("23/01/02 ",(float) 3.22));
        System.out.println("\n----------------------------------------\n");
    }
    public static void clearScreen() {  
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }  
}
