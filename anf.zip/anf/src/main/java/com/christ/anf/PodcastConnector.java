package com.christ.anf;

public abstract class PodcastConnector {
    public abstract void spotify();
    public abstract void appleMusic();
    public abstract void Amazonemusic();
    public abstract void Youtube();
    
}
