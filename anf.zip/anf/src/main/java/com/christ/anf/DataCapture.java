package com.christ.anf;

import java.io.File;
import java.util.Arrays;

public class DataCapture {
    String keyword[]=new String[20];
    DataCapture(String[] array){
        this.keyword=array;
        System.out.println("Inside Data Capture constructor");
        System.out.print(Arrays.toString(this.keyword));
    }
    DataCapture(String keyword){
        File path;
        Utility ut = new Utility();
            ut.putsleep();
        path= new File("/Users/alphinkj/Desktop/ANF/anf/src/main/java/com/christ/anf/image.png");
        DataManager dm= new DataManager();
        System.out.println("\nFunction Overloading\n");
        System.out.print(dm.saveData(path, 3));
        System.out.println("\n****************************************************************\n");
        System.out.print(dm.saveData(keyword));
    }
}
