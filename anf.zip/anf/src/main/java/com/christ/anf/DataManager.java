package com.christ.anf;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class DataManager extends AudioConverter {
    public static void playAudio() throws UnsupportedAudioFileException, IOException, LineUnavailableException{
        audioConverter();
        File audioFile = new File("/Users/alphinkj/Desktop/ANF/NEWS.wav").getAbsoluteFile();
    AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(audioFile);
    Clip clip = AudioSystem.getClip();
    clip.open(audioInputStream);
//Plays audio once
    clip.start();
//Plays the audio in a loop
    //clip.loop(Clip.LOOP_CONTINUOUSLY);
//Stop the audio
    clip.stop();
//optional
    clip.close();
    }
    static int count=1;
    public String saveData(String News){
        count++;
        return String.valueOf(count)+") news about "+ News + " is saved in database";
    }
    public String saveData(File path,float size){
        count++;
        return "the image in location : "+ path.toString() +" is compressed and saved in database";
    }
    public String retrivreData(String Dt, String about){
        return "the information about "+about+ "on date " +Dt+" is retrived";
    }
    public String retrivreData(String dt,float size){
        return "the audio relised on "+dt+ "trimmed upto " +size+" and retrived from database";
    }
}
