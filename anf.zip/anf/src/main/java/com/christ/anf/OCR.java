package com.christ.anf;

public class OCR {
    OCR(){
        new FindPara();
    }
    public static class FindPara{
        FindPara(){
            System.out.println("\n____________________________________________________");
            System.out.println("\nIdentified and saved the paragraph from Image...\n");
            System.out.println("\n____________________________________________________");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    
}
