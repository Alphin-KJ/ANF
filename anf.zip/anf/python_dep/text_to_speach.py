from gtts import gTTS



with open('/Users/alphinkj/Desktop/ANF/NewsFile.txt', 'r') as file:
    data = file.read().rstrip()

tts = gTTS(data)
tts.save('NEWS.wav')
sound_file = '1.wav'